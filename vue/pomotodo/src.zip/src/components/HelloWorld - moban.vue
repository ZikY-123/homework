<template>
<div>
  {{msg}}   
</div>
    
</template>

<script>
export default {
  name: 'HelloWorld',
  data () {
    return {
      msg: '这是我们的实际项目'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
