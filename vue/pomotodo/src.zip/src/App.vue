<template>
  <div id="app">
    
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
/*rest-css*/
html,body{font-size:16px;}
*{margin: 0; padding: 0;}
ul,li{list-style-type: none;}
input{display: block; outline: none; border: 0;}
body{
  background: #f4f4f4;
  font-family: '微软雅黑';
}
/*header*/
</style>
